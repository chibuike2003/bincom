import random
import psycopg2
from collections import Counter
import re

# Define database credentials
host = "your_host"
database = "your_database"
username = "your_username"
password = "your_password"

# Define path to HTML file containing the colors
colors_file = "path/to/colors.html"

# Connect to the database
conn = psycopg2.connect(host=host, database=database, user=username, password=password)

# Create the "colors" table
with conn.cursor() as cur:
    cur.execute("""
        CREATE TABLE colors (
            id SERIAL PRIMARY KEY,
            color VARCHAR(255) NOT NULL,
            frequency INTEGER NOT NULL
        );
    """)

# Parse the colors from the HTML file
colors = []
pattern = re.compile(r'\b\w+\b')
with open(colors_file) as f:
    for line in f:
        match = pattern.findall(line)
        if match:
            colors.extend(match[1:])

# Compute key features about the colors
mean_color = Counter(colors).most_common()[0][0]
most_common_color = Counter(colors).most_common()[0][0]
sorted_colors = sorted(colors)
n = len(sorted_colors)
if n % 2 == 0:
    median_color = sorted_colors[n//2-1]
else:
    median_color = sorted_colors[n//2]
mean = sum(Counter(colors).values()) / len(Counter(colors))
variance = sum((x - mean) ** 2 for x in Counter(colors).values()) / len(Counter(colors))
red_count = Counter(colors)['RED']
total_count = len(colors)
probability = red_count / total_count

# Insert the colors and their frequencies into the "colors" table
with conn.cursor() as cur:
    for color, frequency in Counter(colors).items():
        cur.execute("""
            INSERT INTO colors (color, frequency)
            VALUES (%s, %s);
        """, (color, frequency))

# Commit the changes and close the connection
conn.commit()
conn.close()

# To write a recursive searching algorithm to search for a number entered by the user in a list of numbers, you can follow these steps:

# Define a function that takes a list and a target number as arguments.

# Use recursion to search for the target number in the list.

# If the list is empty, return False.

# If the first element of the list is equal to the target number, return True.

# Otherwise, call the function recursively with the rest of the list (excluding the first element) and the same target number.

# Here's an example code snippet that demonstrates these steps:


def recursive_search(lst, target):
    if not lst:
        return False
    elif lst[0] == target:
        return True
    else:
        return recursive_search(lst[1:], target)

# Example




